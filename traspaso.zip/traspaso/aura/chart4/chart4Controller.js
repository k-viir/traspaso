({
    doInit: function (cmp, evt, helper) {
        let getKpiValues = cmp.get('c.getRecordMonthlyValues');
        getKpiValues.setParams({recordId: cmp.get('v.recordId')});
        getKpiValues.setCallback(this, function(response2) {
            let state2 = response2.getState();
            if (state2 === 'SUCCESS') {
                console.log(response2.getReturnValue());
                cmp.set('v.kpiValues', response2.getReturnValue().map((elem) => {
                    if (elem.percentageValue == 0) {
                        elem.percentageValue = 1;
                    }
                    return elem;
                }));
                helper.setChartData(cmp, evt, helper);
            }
        });
        $A.enqueueAction(getKpiValues);
    }
})